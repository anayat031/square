var paymentForm = '';

jQuery(document).ready(function()
{
    
    var paymentMethod = jQuery('input[name="paymentmethod"]'), /*-----checkout page----*/
        frm = jQuery('#frmCheckout'),/*-----checkout page----*/
        newCcForm = jQuery('#frmNewCc'),/*---clientarea.php?action=creditcard---*/
        paymentForm1 = jQuery('#frmPayment'),/*---creditcard.php---*/
        adminCreditCard = jQuery('#frmCreditCardDetails'); /*----admin creditcard details--*/
        
        
    if (paymentMethod.length) 
    {
        //order checkout
        /*
        if (existingToken)
        {
            jQuery('#creditCardInputFields').remove();
            frm.append("<input type='hidden' name='stripeToken' value='" + existingToken + "' />");
            return '';
        }
        */

        var newOrExisting = jQuery('input[name="ccinfo"]'),
            selectedPaymentMethod = jQuery('input[name="paymentmethod"]:checked').val();
            
        //checkApplePayAvailableForCart();

        if (selectedPaymentMethod === 'square') 
        {
            if (newOrExisting.val() === 'useexisting') 
            {
                frm.off('submit', getCardNonce);
                    
                disable_square();
            }
            else
            {
                enable_square();
            }
        }

        paymentMethod.on('ifChecked change', function()
        {
            selectedPaymentMethod = jQuery(this).val();
            
            if (selectedPaymentMethod === 'square') 
            {
                
                if(newOrExisting.val() === 'useexisting') 
                {
                    frm.off('submit', getCardNonce);
                    
                    disable_square();
                }
                else
                {
                    enable_square();
                }
            }
            else
            {
                disable_square();
            }
        });
        
        newOrExisting.on('ifChecked change', function() 
        {  
            frm.off('submit', getCardNonce);
            
            if (selectedPaymentMethod === 'square') 
            {
                if (jQuery(this).val() !== 'useexisting') 
                {
                    enable_square();
                }
                else
                {
                    disable_square();
                }
            }
          
        });
    }
    else if (newCcForm.length) 
    {
        /*---clientarea.php?action=creditcard---*/
        
        newCcForm.prepend("<div id='sq-form'></div>");
        
        var divobj = jQuery("#sq-form");
        var expYear = (new Date().getFullYear() + 2).toString().substr(-2);/*--two digit format---*/
        
        newCcForm.find('#inputCardNumber').val('4111 1111 1111 1111').parents("div.form-group").hide('fast');
        newCcForm.find('#inputCardExpiry').val('11').parents("div.form-group").hide('fast');
        newCcForm.find('select[name="ccexpiryyear"]').val(expYear).parents("div.form-group").hide('fast');
        newCcForm.find('#inputCardCVV').val('123').parents("div.form-group").hide('fast');
        newCcForm.find("#inputCardType").parents("div.form-group").hide('fast');
    
        squareFormInit(divobj,newCcForm);
       
    } 
    else if (paymentForm1.length) 
    {
        /*--creditcard.php--*/
        
        if(jQuery('input[name="ccinfo"]:checked').val() == 'new') 
        {
            enable_payment_square();
        }
        else
        {
            paymentForm1.off('submit',getCardNonce);
            removeSquareForm();
            //paymentForm1.find('#inputCardCvv').parents('div.form-group').hide('fast');
        }
        
        jQuery('input[name="ccinfo"]').on('change', function()
        {
            if (jQuery(this).val() == 'new')
            {
                enable_payment_square();
            }
            else
            {
                //paymentForm1.find('#inputCardCvv').parents('div.form-group').hide('fast');
                paymentForm1.off('submit',getCardNonce);
                removeSquareForm();
            }
        });
    } 
    else if (adminCreditCard.length) 
    {
        /*----admin creditcard details--*/
        adminCreditCard.prepend("<div id='sq-form'></div>");
        
        var divobj = jQuery("#sq-form");
        
        var expYear = new Date().getFullYear() + 2;/*--4 digit format---*/
        
        adminCreditCard.find('table.padded-fields').hide('fast');
        adminCreditCard.find('#cctype').val('visa').parents('tr#rowCardType').hide('fast');
        adminCreditCard.find('#inputCardNumber').val('4111 1111 1111 1111').hide('fast');
        adminCreditCard.find('#inputCardMonth').val('12').hide('fast');
        adminCreditCard.find('#inputCardYear').val(expYear).hide('fast');
        adminCreditCard.find('#cardcvv').val('123').hide('fast');

        // same as above - Firefox issues
        //adminCreditCard.find('#btnSaveChanges').removeAttr('name');

        //adminCreditCard.on('submit', validateAdminStripe);
       
       squareFormInit(divobj,adminCreditCard);
    }
});

/**
 * Define callback function for "sq-button"
 * @param {*} event
 */
function getCardNonce(event) 
{
    event.preventDefault();
    
    /*--Disable button---*/
    
    if(event.data.find('#btnCompleteOrder').length)
    {
      /*---checkout---*/
      event.data.find('#btnCompleteOrder').attr('disabled', 'disabled').addClass('disabled');
    }
    else if(event.data.find('#btnSubmit').length)
    {
      /*----creditcard.php----*/
      event.data.find('#btnSubmit').attr('disabled', 'disabled').addClass('disabled');
    }
    else if(event.data.find('#btnSubmitNewCard').length)
    {
      /*---clientarea.php?action=creditcard---*/
      event.data.find('#btnSubmitNewCard').attr('disabled', 'disabled').addClass('disabled');
    }
    else if(event.data.find('#btnSaveChanges').length)
    {
      /*----admin creditcard details--*/
      event.data.find('#btnSaveChanges').attr('disabled', 'disabled').addClass('disabled');
    }
    else
    {
       console.log("Submit button not found.");
    }
    
    paymentForm.requestCardNonce();
}



function squareFormInit(divAppendObj,orderformobj)
{
    divAppendObj.after(`<div class="sq-payment-form" id="squarformblock">
    
        <div id="sq-ccbox">

            <div class="sq-field">
              <label class="sq-label">Card Number</label>
              <div id="sq-card-number"></div>
            </div>
            <div class="sq-field-wrapper">
              <div class="sq-field sq-field--in-wrapper">
                <label class="sq-label">CVV</label>
                <div id="sq-cvv"></div>
              </div>
              <div class="sq-field sq-field--in-wrapper">
                <label class="sq-label">Expiration</label>
                <div id="sq-expiration-date"></div>
              </div>
              <div class="sq-field sq-field--in-wrapper">
                <label class="sq-label">Postal</label>
                <div id="sq-postal-code"></div>
              </div>
            </div>
            <div class="sq-field">

            </div>

            <div id="error" style="display:none;"></div>
          </form>
        </div>
      </div>`);

    paymentForm = new SqPaymentForm(
                                    {

                                        /*---Initialize the payment form elements--*/
                                        applicationId: applicationId,
                                        locationId: locationId,
                                        inputClass: 'sq-input',
                                        //autoBuild: false,

                                        /*---Customize the CSS for SqPaymentForm iframe elements---*/
                                        inputStyles: [{
                                                        //backgroundColor: 'transparent',
                                                        //color: '#333333',
                                                        //fontFamily: '"Helvetica Neue", "Helvetica", sans-serif',
                                                        //fontSize: '16px',
                                                        //fontWeight: '400',
                                                        //placeholderColor: '#8594A7',
                                                        //placeholderFontWeight: '400',
                                                        padding: '16px',
                                                        _webkitFontSmoothing: 'antialiased',
                                                        _mozOsxFontSmoothing: 'grayscale'
                                                    }],

                                        // Initialize Apple Pay placeholder ID
                                        applePay: false,

                                        // Initialize Masterpass placeholder ID
                                        masterpass: false,

                                        // Initialize the credit card placeholders
                                        cardNumber: {
                                          elementId: 'sq-card-number',
                                          placeholder: '• • • •  • • • •  • • • •  • • • •'
                                        },
                                        cvv: {
                                          elementId: 'sq-cvv',
                                          placeholder: 'CVV'
                                        },
                                        expirationDate: {
                                          elementId: 'sq-expiration-date',
                                          placeholder: 'MM/YY'
                                        },
                                        postalCode: {
                                          elementId: 'sq-postal-code',
                                          placeholder: '12345'
                                        },

                                        callbacks: 
                                        {
                                            /*
                                             * callback function: cardNonceResponseReceived
                                             * Triggered when: SqPaymentForm completes a card nonce request
                                             */
                                            cardNonceResponseReceived: function(errors, nonce, cardData, billingContact, shippingContact) 
                                            {
                                                if (errors)
                                                {
                                                    var error_html = "<ul style='list-style-type: none;'>";

                                                    for (var i =0; i < errors.length; i++)
                                                    {
                                                      error_html += "<li> " + errors[i].message + " </li>";
                                                    }
                                                    error_html += "</ul>";

                                                  /*--Show the errors on the form:--*/
                                                  orderformobj.find('.gateway-errors').html(error_html).removeClass('hidden');
                                                  square_scrollToError();
                                                  
                                                  /*--Re-enable submission--*/
                                                  
                                                    if(orderformobj.find('#btnCompleteOrder').length)
                                                    {
                                                      /*---checkout---*/
                                                      orderformobj.find('#btnCompleteOrder').removeAttr('disabled').removeClass('disabled');
                                                    }
                                                    else if(orderformobj.find('#btnSubmit').length)
                                                    {
                                                      /*----creditcard.php----*/
                                                      orderformobj.find('#btnSubmit').removeAttr('disabled').removeClass('disabled').find('span').toggleClass('hidden');
                                                    }
                                                    else if(orderformobj.find('#btnSubmitNewCard').length)
                                                    {
                                                      /*---clientarea.php?action=creditcard---*/
                                                      orderformobj.find('#btnSubmitNewCard').removeAttr('disabled').removeClass('disabled');
                                                    }
                                                    else if(orderformobj.find('#btnSaveChanges').length)
                                                    {
                                                      /*----admin creditcard details--*/
                                                      orderformobj.find('#btnSaveChanges').removeAttr('disabled').removeClass('disabled');
                                                    }
                                                    else
                                                    {
                                                       console.log("Submit button not found.");
                                                    }
                                                  
                                                  document.getElementById("error").innerHTML = error_html;
                                                  document.getElementById('sq-card-number').disabled = false;

                                                  return;
                                                }
                                                else
                                                {
                                                    orderformobj.off('submit', getCardNonce);
                                                    document.getElementById("error").innerHTML = "";
                                                    orderformobj.find('.gateway-errors').html('').addClass('hidden');
                                                  
                                                  /*Insert the token ID into the form so it gets submitted to the server:*/
                                                  orderformobj.append(jQuery('<input type="hidden" name="nonce">').val(nonce));
                                                  
                                                  /*--Submit the form:--*/
                                                  
                                                  if(orderformobj.find('#btnCompleteOrder').length)
                                                  {
                                                      /*---checkout---*/
                                                      orderformobj.find('#btnCompleteOrder').removeAttr('disabled').removeClass('disabled').click().addClass('disabled').attr('disabled', 'disabled');
                                                  }
                                                  else if(orderformobj.find('#btnSubmit').length)
                                                  {
                                                      /*----creditcard.php----*/
                                                      orderformobj.find('#btnSubmit').removeAttr('disabled').removeClass('disabled').click().addClass('disabled').attr('disabled', 'disabled');
                                                  }
                                                  else if(orderformobj.find('#btnSubmitNewCard').length)
                                                  {
                                                      /*---clientarea.php?action=creditcard---*/
                                                      orderformobj.append(jQuery('<input type="hidden" name="squareUpdateCc">').val('true'));
                                                      orderformobj.find('#btnSubmitNewCard').removeAttr('disabled').removeClass('disabled').click().addClass('disabled').attr('disabled', 'disabled');
                                                  }
                                                  else if(orderformobj.find('#btnSaveChanges').length)
                                                  {
                                                      /*----admin creditcard details--*/
                                                      orderformobj.append(jQuery('<input type="hidden" name="squareUpdateCc">').val('true'));
                                                      orderformobj.find('#btnSaveChanges').removeAttr('disabled').removeClass('disabled').click().addClass('disabled').attr('disabled', 'disabled');
                                                      
                                                  }
                                                  else
                                                  {
                                                    console.log("Submit button not found.");
                                                  }
                                                  
                                                }

                                            },

                                            /*
                                             * callback function: unsupportedBrowserDetected
                                             * Triggered when: the page loads and an unsupported browser is detected
                                             */
                                            unsupportedBrowserDetected: function () 
                                            {
                                              /* PROVIDE FEEDBACK TO SITE VISITORS */
                                              orderformobj.find('.gateway-errors').html("<p>Unsupported browser detected.</p>").removeClass('hidden');
                                              square_scrollToError();
                                            },

                                            /*
                                             * callback function: inputEventReceived
                                             * Triggered when: visitors interact with SqPaymentForm iframe elements.
                                             */
                                            inputEventReceived: function (inputEvent) 
                                            {
                                              switch (inputEvent.eventType) 
                                              {
                                                case 'focusClassAdded':
                                                  /* HANDLE AS DESIRED */
                                                  break;
                                                case 'focusClassRemoved':
                                                  /* HANDLE AS DESIRED */
                                                  break;
                                                case 'errorClassAdded':
                                                  document.getElementById("error").innerHTML = "Please fix card information errors before continuing.";
                                                  break;
                                                case 'errorClassRemoved':
                                                  /* HANDLE AS DESIRED */
                                                  document.getElementById("error").style.display = "none";
                                                  break;
                                                case 'cardBrandChanged':
                                                  /* HANDLE AS DESIRED */
                                                  break;
                                                case 'postalCodeChanged':
                                                  /* HANDLE AS DESIRED */
                                                  break;
                                              }
                                            },

                                            /*
                                             * callback function: paymentFormLoaded
                                             * Triggered when: SqPaymentForm is fully loaded
                                             */
                                            paymentFormLoaded: function () 
                                            {
                                                /* HANDLE AS DESIRED */
                                                paymentForm.recalculateSize();
                                                console.log("The form loaded!");
                                            }
                                        }
    });

    if (SqPaymentForm.isSupportedBrowser()) 
    {
        paymentForm.build();
    }

    orderformobj.on('submit',orderformobj, getCardNonce);/*--event,data,function--*/
}


/*
 * checkout form
 */

function enable_square()
{
    var frm1 = jQuery('#frmCheckout');
    var divobj = jQuery("#creditCardInputFields");
    
    var expDate = '11/'+(new Date().getFullYear() + 2).toString().substr(-2);/*---MM/YY---*/
    
    frm1.find('#inputCardNumber').val('4111 1111 1111 1111').parent().hide('fast');
    frm1.find('#inputCardExpiry').val(expDate).parent().hide('fast');
    frm1.find('#inputCardCVV').val('123').parent().hide('fast');
    frm1.find("#cctype").parent().hide('fast');
    frm1.find('#newCardInfo').hide('fast');
    
    squareFormInit(divobj,frm1);

}

function disable_square()
{
    var frm = jQuery('#frmCheckout');
    
    //frm.find('#inputCardCvvExisting').attr('name', 'cccvvexisting');
    frm.find('#inputCardNumber').val('').parent().show();
    frm.find('#inputCardExpiry').val('').parent().show();
    frm.find('#inputCardCVV').val('').parent().show();
    frm.find("#cctype").parent().show();
    frm.find('#newCardInfo').show();
    
    frm.off('submit', getCardNonce);
    removeSquareForm();
}

function removeSquareForm()
{
    $("#squarformblock").remove();
}

/*
 * creditcard.php
 */

function enable_payment_square() 
{
    var paymentForm1 = jQuery('#frmPayment');
    var divobj = jQuery('#billingAddressSummary');
    
    var expYear = new Date().getFullYear() + 2;/*---YYYY---*/
    
    paymentForm1.find('#cctype').parents('div.form-group').hide('fast');
    paymentForm1.find('#inputCardNumber').val('4111 1111 1111 1111').parents('div.form-group').hide('fast');
    paymentForm1.find('#inputCardExpiry').val('12').parents('div.form-group').hide('fast');
    paymentForm1.find('#inputCardExpiryYear').val(expYear).parents('div.form-group').hide('fast');
    
    paymentForm1.find('#inputCardCvv').val('123').parents('div.form-group').hide('fast');
    
    squareFormInit(divobj,paymentForm1);
}

function square_scrollToError() 
{
    jQuery('html, body').animate(
        {
            scrollTop: jQuery('.gateway-errors').offset().top - 50
        },
        500
    );
}